@extends('base')

@section('title', 'Dashboard')

@section('style')
@stop

@section('bodyClass', 'site-menubar-fold site-menubar-keep')

@section('content')	
@endsection

@section('script')
@endsection