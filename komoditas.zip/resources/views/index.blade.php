@extends('base')

@section('title', 'Dashboard')

@section('style')
@stop

@section('bodyClass', 'site-menubar-fold site-menubar-keep')

@section('content')	
	<section class="content-header">
		<h1>
			Title
		</h1>
	</section>
	<!-- Main content -->
	<section class="content">
	</section>
@endsection

@section('script')
@endsection